﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication_EProject.Models.NhanVien
{
    public class NhanVienRoleMapping
    {
        [Key]
        public int MapId { get; set; }

        [Required(ErrorMessage = "Please having data")]
        public int Employee_ID { get; set; }

        [Required(ErrorMessage = "Please having data")]
        public int Role_ID { get; set; }

        public virtual NhanVien NhanVien { get; set; }
        public virtual Role Role { get; set; }
    }
}